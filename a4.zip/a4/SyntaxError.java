package a4;
import java.util.NoSuchElementException;

public class SyntaxError extends NoSuchElementException {
}
